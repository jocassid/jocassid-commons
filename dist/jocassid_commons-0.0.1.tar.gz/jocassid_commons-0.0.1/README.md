# jocassid-commons
Miscellaneous utility code written in Python
